package com.EnviroVerse.EnviroVerse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnviroVerseApplicationTests {

	@Test
	void contextLoads() {
	}

}
