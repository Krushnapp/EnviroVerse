package com.EnviroVerse.EnviroVerse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnviroVerseApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnviroVerseApplication.class, args);
	}

}
